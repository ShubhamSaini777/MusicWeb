from django.contrib.auth import(authenticate,get_user_model,login,logout,)
from django import forms
from .models import table1
from django.contrib.auth.models import User



class userform(forms.ModelForm):
	username = forms.CharField(widget=forms.TextInput(
	attrs={'placeholder':'Username here' }),required=True, max_length=50)
	email = forms.CharField(widget=forms.EmailInput(
	attrs={'placeholder':'Email'}),required=True, max_length=50)
	password = forms.CharField(widget=forms.PasswordInput(
	attrs={'placeholder':'Enter Password'}),required=True, max_length=50)
	class Meta:
		model = User
		fields = ['username','email','password']


class Loginform(forms.ModelForm):
	username = forms.CharField(widget=forms.TextInput(
	attrs={'placeholder':'Username here' }),required=True, max_length=50)

	password = forms.CharField(widget=forms.PasswordInput(
	attrs={'placeholder':'Enter Password'}),required=True, max_length=50)
	class Meta:
		model = User
		fields = ['username','password']
