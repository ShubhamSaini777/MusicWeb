#from django.http import Http404
from . models import Album,Songs,Plylist
from django.shortcuts import render,get_object_or_404,redirect
from django.http import HttpResponse
from django.contrib.auth import(authenticate,get_user_model,login,logout,)
from .models import table1
from . form import userform,Loginform
#from .formslogin import UserLoginForm
from django.contrib import messages
from django.contrib import auth
from django.contrib.auth.models import User
from django.core.exceptions import ObjectDoesNotExist
from django.views import generic
from django.views.generic import  View
from django.views.generic.edit import CreateView,UpdateView,DeleteView
from django.contrib.auth.hashers import make_password,check_password
from django.urls import reverse_lazy


class IndexView(generic.ListView):
    template_name = 'music/index.html'
    context_object_name = 'all_album'
    def get_queryset(self):
        return Album.objects.all()


class ReverseAlbums(generic.ListView):
    context_object_name = 'reverse_album'
    def get_queryset(self):
        return Album.objects.all().order_by('-id')


class SongsView(generic.ListView):
    template_name = 'music/Songs.html'
    context_object_name = 'all_songs'


    def get_queryset(self):
        return Songs.objects.all()


class UserPlaylist(generic.ListView):
    template_name = 'music/Playlist.html'
    context_object_name = 'user_playlist'


    def get_queryset(self):

        return Plylist.objects.filter(username=self.request.user.username)

class Userdata(UserPlaylist,generic.ListView):
    def get_context_data(self,**kwargs):
            context = super(Userdata, self).get_context_data(**kwargs)

            context['topsong'] = Plylist.objects.filter(username=self.request.user.username)[:1]

            return context


class UserSong(UserPlaylist, generic.ListView):
    def get_context_data(self, **kwargs):
        context = super(UserSong, self).get_context_data(**kwargs)

        context['topsong'] = Plylist.objects.filter(id=self.kwargs["pk"])[:1]

        return context







class DetailsView(generic.DetailView):
      model=Album
      template_name = 'music/detail.html'


class AlbumCreate(CreateView,ReverseAlbums):
    model = Album

    fields = ['album', 'genre', 'artist', 'album_logo','is_favourite']
    template_name = 'music/album_form.html'






class AlbumDelete(DeleteView):
    model = Album
    success_url =reverse_lazy('Music:index')


class SongsCreate(CreateView):
    model = Songs
    fields = ['album', 'SongTitle', 'file_type', 'is_favourite']


def SongsPlaylist(request,pk):
    try:
       if Plylist.objects.filter(song=Songs.objects.get(pk=pk),username=request.user.username).exists()==False:
           play = Plylist(song=Songs.objects.get(pk=pk), username=request.user.username)
           play.save()


    except (KeyError, Songs.DoesNotExist):
        return redirect('Music:songs')

    return redirect('Music:songs')
def DeletePlaylistSong(request,pk):
    try:
       if Plylist.objects.filter(id=pk).exists():
           play = Plylist.objects.filter(id=pk).delete()



    except (KeyError, Songs.DoesNotExist):
        return redirect('Music:songs')

    return redirect('Music:playlists')

def logouts(request):

    logout(request)

    return redirect('Music:login')

def logout_view(request):
    logout(request)
# def index(request):
#     album=Album.objects.all()
#
#     context={
#       'album':album,
#     }
#     return render(request,"music/index.html",{'album':album})
#
#
# def detail(request,album_id):
#     album=get_object_or_404(Album,pk=album_id)
#     return render(request,"music/detail.html",{'album':album})
#
#
# def basic(request,album_id):
#     all_data=Album.objects.all()
#     context={
#         'all_data':all_data,
#     }
#     return  render(request,'Music/indexshow.html',context)
# #HttpResponse('<h1>Welcome to basic page django with id '+str(album_id)+'</h1>')
#
#
# def favourite(request,album_id):
#     album=get_object_or_404(Album,pk=album_id)
#     try:
#         selected_song=album.songs_set.get(pk=request.POST['song'])
#     except (KeyError,Songs.DoesNotExist):
#          return render(request,"music/fav.html",{'album':album,
#         'error':"You did not select a valid song",})
#     else:
#         selected_song.is_favourite=True
#         selected_song.save()
#         return render(request,'Music/detail.html',{'album':album})
#
def SongsFavourite(request,song_id):

    try:
       selected_song=Songs.objects.get(pk=song_id)
    except (KeyError,Songs.DoesNotExist):
       return redirect('Music:index')
    else:

         if selected_song.is_favourite is not True:
             selected_song.is_favourite = True
         else:
             selected_song.is_favourite = False
         selected_song.save()
         album = get_object_or_404(Album, pk=selected_song.album.id)
         return render(request,'Music/detail.html',{'album':album})



def AlbumFavourite(request,album_id):

    try:
       selected_album=Album.objects.get(pk=album_id)
    except (KeyError,Album.DoesNotExist):
       return redirect('Music:index')
    else:

         if selected_album.is_favourite is not True:
             selected_album.is_favourite = True
         else:
             selected_album.is_favourite = False
         selected_album.save()

         return redirect('Music:index')
# def uform(request):
# 	if request.method == "POST":
# 		form=userform(request.POST)
# 		if form.is_valid():
# 			username =form.cleaned_data['username']
# 			email =form.cleaned_data['email']
# 			password =form.cleaned_data['password']
# 			User.objects.create_user(username=username, email=email, password=password,)
# 			form.save()
# 			messages.success(request,'Succesfully Register')
# 	else:
# 		form=userform()
# 	return render(request, 'Music/form.html',{'form':form})
#
#
#
# def logout(request):
# 	auth.logout(request)
# 	return render(request,'music/login.html')

# def login(request):
#     form_class = userform
#     template_name = 'Music/login.html'
#
#     # display blank form
#     def get(self, request):
#         form = self.form_class(None)
#         return render(request, self.template_name, {'form': form})
#     def post(self,request):
#         form=self.form_class(request.POST)
#         if form.is_valid():
#             user=form.save(commit=False)
#             #cleaned (normalized )data
#             username=form.cleaned_data['us']
#             password=form.cleaned_data['ps']
#             #user.set_password(password)
#
#             #returns user objects if credentials are correct
#             user=authenticate(username=username,password=password)
#             if user is not None:
#                 if user.is_active:
#                     login(request,user)
#                     return redirect('music:index')
#     return render(request,'music/login.html',{})
#       # if request.method == "POST":
#       #
#       #     uss=request.POST['un']
#       #     pss=request.POST['ps']
#       #     try:
#       #         d1=User.objects.get(username=uss)
#       #         d2=User.objects.get(password=pss)
#       #     except User.DoesNotExist:
#       #         d1 = None
#       #         d2 = None
#       #         if(uss==d1 and pss==d2):
#       #             return render(request,'song/welcome.html')
#       #         else:
#       #             return render(request,'song/login1.html')
#       #     else:
#       #         user = authenticate(uss=d1.username, pss=d1.password)
#       #         if user is not None:
#       #             if user.is_active:
#       #                 login(request, user)
#       #                 return redirect('music:index')
#       #
#       #         #if(uss==d1.username and pss==d2.password):
#       #          #   request.session['username1'] = uss
#       #          #   request.session['password'] = pss
#       #
#       #         else:
#       #            return render(request,'music/login.html')
#       #
#       # return render(request,'music/login.html')

def Login(request):
    if request.method == "POST":
        uss = request.POST['un']
        pss = request.POST['ps']
        passw=make_password(pss)
        user1 = User.objects.get(username=uss)
        if check_password(pss,user1.password):
            user = authenticate(request, username=uss, password=pss)
            if user is not None:
                if user.is_active:
                    login(request, user)
                    return redirect('Music:index')
            else:
                return redirect('Music:login')
        else:
            return redirect('Music:login')

        # user = auth.authenticate(username='Users',
        #                  password='pbkdf2_sha256$120000$rxKfQuyIYg08$RaKCw6hbsVjEgVGUtgHN3E/KASX7X+uRnHNGHDU0oHA='
        #                          )
        # if user is not None:
        #     auth.login(request, user)
        #     return render(request, "Music/welcome.html")
        # else:
        #     messages.error(request, 'Username or password not exist')

    return render(request, "Music/login.html")


class UserLoginView(View):
    form_class = Loginform
    template_name = 'Music/Login_form.html'

    # display blank form
    def get(self, request):
        form = self.form_class(None)
        return render(request, self.template_name, {'form': form})

    # process form data
    def post(self, request):
        form = self.form_class(request.POST)
        if form.is_valid():
             username = form.cleaned_data('username')
             passs = form.cleaned_data['password']
             #password = make_password(passs)
             userm=User.objects.create_user(username=username, email=email, password=passs )
             userm.save()

             #return HttpResponse(username+" "+password)
            # user = authenticate(request, username=username, password=password)
            # if user is not None:
            #     if user.is_active:
            #         login(request, user)
            #         return redirect('music:index')




        return render(request, self.template_name, {'form': form})


class UserFormView(View):
    form_class=userform
    template_name='Music/Registration_form.html'

    #display blank form
    def get(self,request):
        form =self.form_class(None)
        return  render(request,self.template_name,{'form':form})
    #process form data
    def post(self,request):
        form=self.form_class(request.POST)
        if form.is_valid():
            #user=form.save(commit=False)
            #cleaned (normalized )data
            username = form.cleaned_data['username']
            password=form.cleaned_data['password']
            #password = make_password(passs)
            email=form.cleaned_data['email']
            # #user.set_password(password)

            user=User.objects.create_user(username,email,password)
            user.save()
            #return  HttpResponse('saved')
            #returns user objects if credentials are correct
            user=authenticate(username=username,password=password)
            if user is not None:
                if user.is_active:
                    login(request,user)
                    return  redirect('Music:index')
        return render(request,self.template_name,{'form':form})




