from django.db import models
from django.urls import reverse


class Album(models.Model):
    album = models.CharField(max_length=100)
    genre = models.CharField(max_length=100)
    artist = models.CharField(max_length=100)
    album_logo = models.FileField()
    is_favourite = models.BooleanField(default=False)

    def get_absolute_url(self):
        return reverse('Music:detail',kwargs={'pk':self.pk})

    def __str__(self):
        return self.album+'-'+self.artist+'-'+self.genre


class Songs(models.Model):
    album=models.ForeignKey(Album,on_delete=models.CASCADE)
    SongTitle= models.CharField(max_length=100)
    file_type=models.FileField()
    is_favourite=models.BooleanField(default=False)

    def get_absolute_url(self):
        return reverse('Music:index')

    def __str__(self):
        return str(self.album)+'-'+self.SongTitle+'-'+str(self.file_type)


class Plylist(models.Model):
    song=models.ForeignKey(Songs,on_delete=models.CASCADE)
    username=models.CharField(max_length=40)

    def get_absolute_url(self):
        return reverse('Music:index')

    def __str__(self):
        return str(self.song)



class table1(models.Model):
	username = models.CharField(max_length=40)
	email = models.CharField(max_length=40)
	password = models.CharField(max_length=40)

